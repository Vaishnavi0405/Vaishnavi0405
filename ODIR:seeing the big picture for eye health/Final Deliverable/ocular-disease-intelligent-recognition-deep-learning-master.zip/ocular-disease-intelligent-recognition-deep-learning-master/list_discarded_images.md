# List of discarded images

| Fundus         | Discard Reason                        | Fundus         | Discard Reason    |
|----------------|---------------------------------------|----------------|-------------------|
| 20_right.jpg   | Lens Dust                             | 2450_left.jpg  | Lens Dust         |
| 36_left.jpg    | Lens Dust                             | 2450_right.jpg | Lens Dust         |
| 36_right.jpg   | Lens Dust                             | 2453_left.jpg  | Lens Dust         |
| 39_right.jpg   | Lens Dust                             | 2453_right.jpg | Lens Dust         |
| 57_left.jpg    | Lens Dust                             | 2455_left.jpg  | Lens Dust         |
| 57_right.jpg   | Lens Dust                             | 2455_right.jpg | Lens Dust         |
| 65_left.jpg    | Lens Dust                             | 2464_left.jpg  | Lens Dust         |
| 70_left.jpg    | Lens Dust                             | 2464_right.jpg | Lens Dust         |
| 70_right.jpg   | Lens Dust                             | 2468_left.jpg  | Lens Dust         |
| 80_left.jpg    | Lens Dust                             | 2468_right.jpg | Lens Dust         |
| 80_right.jpg   | Lens Dust                             | 2477_right.jpg | Lens Dust         |
| 94_left.jpg    | Lens Dust                             | 2478_left.jpg  | Lens Dust         |
| 122_left.jpg   | Lens Dust                             | 2478_right.jpg | Lens Dust         |
| 124_right.jpg  | Lens Dust                             | 2483_left.jpg  | Lens Dust         |
| 154_left.jpg   | Lens Dust                             | 2486_left.jpg  | Lens Dust         |
| 154_right.jpg  | Lens Dust                             | 2491_left.jpg  | Lens Dust         |
| 183_left.jpg   | Lens Dust                             | 2491_right.jpg | Lens Dust         |
| 184_left.jpg   | Lens Dust                             | 2494_left.jpg  | Lens Dust         |
| 184_right.jpg  | Lens Dust                             | 2494_right.jpg | Lens Dust         |
| 201_left.jpg   | Lens Dust                             | 2495_left.jpg  | Lens Dust         |
| 201_right.jpg  | Lens Dust                             | 2496_left.jpg  | Lens Dust         |
| 203_right.jpg  | Lens Dust                             | 2509_left.jpg  | Lens Dust         |
| 222_left.jpg   | Lens Dust                             | 2515_right.jpg | Lens Dust         |
| 222_right.jpg  | Lens Dust                             | 2516_left.jpg  | Lens Dust         |
| 232_left.jpg   | Lens Dust                             | 2516_right.jpg | Lens Dust         |
| 232_right.jpg  | Lens Dust                             | 2520_right.jpg | Lens Dust         |
| 246_left.jpg   | Lens Dust                             | 2536_left.jpg  | Lens Dust         |
| 246_right.jpg  | Lens Dust                             | 2536_right.jpg | Lens Dust         |
| 248_left.jpg   | Lens Dust                             | 2546_left.jpg  | Lens Dust         |
| 248_right.jpg  | Lens Dust                             | 2546_right.jpg | Lens Dust         |
| 251_right.jpg  | Lens Dust                             | 2550_left.jpg  | Lens Dust         |
| 263_left.jpg   | Lens Dust                             | 2550_right.jpg | Lens Dust         |
| 263_right.jpg  | Lens Dust                             | 2566_left.jpg  | Lens Dust         |
| 267_right.jpg  | Lens Dust                             | 2571_left.jpg  | Lens Dust         |
| 322_left.jpg   | Lens Dust                             | 2571_right.jpg | Lens Dust         |
| 324_right.jpg  | Lens Dust                             | 2578_left.jpg  | Lens Dust         |
| 372_left.jpg   | Low Image Quality                     | 2578_right.jpg | Lens Dust         |
| 372_right.jpg  | Low Image Quality                     | 2580_left.jpg  | Lens Dust         |
| 380_right.jpg  | Lens Dust                             | 2580_right.jpg | Lens Dust         |
| 393_left.jpg   | Lens Dust                             | 2582_left.jpg  | Lens Dust         |
| 393_right.jpg  | Lens Dust                             | 2582_right.jpg | Lens Dust         |
| 395_right.jpg  | Lens Dust                             | 2589_left.jpg  | Lens Dust         |
| 409_left.jpg   | Lens Dust                             | 2589_right.jpg | Lens Dust         |
| 409_right.jpg  | Lens Dust                             | 2598_left.jpg  | Lens Dust         |
| 438_left.jpg   | Lens Dust                             | 2598_right.jpg | Lens Dust         |
| 444_left.jpg   | Lens Dust                             | 2606_left.jpg  | Lens Dust         |
| 444_right.jpg  | Lens Dust                             | 2606_right.jpg | Lens Dust         |
| 459_left.jpg   | Lens Dust                             | 2607_left.jpg  | Lens Dust         |
| 459_right.jpg  | Lens Dust                             | 2607_right.jpg | Lens Dust         |
| 460_right.jpg  | Lens Dust                             | 2611_left.jpg  | Lens Dust         |
| 465_left.jpg   | Lens Dust                             | 2611_right.jpg | Lens Dust         |
| 470_left.jpg   | Lens Dust                             | 2620_left.jpg  | Lens Dust         |
| 471_left.jpg   | Lens Dust                             | 2620_right.jpg | Lens Dust         |
| 472_right.jpg  | Lens Dust                             | 2629_left.jpg  | Lens Dust         |
| 474_left.jpg   | Lens Dust                             | 2648_left.jpg  | Lens Dust         |
| 474_right.jpg  | Lens Dust                             | 2648_right.jpg | Lens Dust         |
| 494_left.jpg   | Optic disk photographically invisible | 2652_left.jpg  | Lens Dust         |
| 505_left.jpg   | Lens Dust                             | 2656_left.jpg  | Lens Dust         |
| 505_right.jpg  | Lens Dust                             | 2656_right.jpg | Lens Dust         |
| 528_left.jpg   | Lens Dust                             | 2661_left.jpg  | Lens Dust         |
| 539_left.jpg   | Lens Dust                             | 2664_left.jpg  | Lens Dust         |
| 539_right.jpg  | Lens Dust                             | 2664_right.jpg | Lens Dust         |
| 558_right.jpg  | Lens Dust                             | 2674_left.jpg  | Lens Dust         |
| 568_right.jpg  | Lens Dust                             | 2674_right.jpg | Lens Dust         |
| 577_left.jpg   | Lens Dust                             | 2676_left.jpg  | Lens Dust         |
| 577_right.jpg  | Lens Dust                             | 2686_left.jpg  | Lens Dust         |
| 586_left.jpg   | Lens Dust                             | 2686_right.jpg | Lens Dust         |
| 586_right.jpg  | Lens Dust                             | 2691_left.jpg  | Lens Dust         |
| 593_left.jpg   | Lens Dust                             | 2694_left.jpg  | Lens Dust         |
| 594_left.jpg   | Lens Dust                             | 2694_right.jpg | Lens Dust         |
| 624_left.jpg   | Lens Dust                             | 2700_left.jpg  | Lens Dust         |
| 627_left.jpg   | Lens Dust                             | 2700_right.jpg | Lens Dust         |
| 631_left.jpg   | Lens Dust                             | 2719_left.jpg  | Lens Dust         |
| 631_right.jpg  | Lens Dust                             | 2719_right.jpg | Lens Dust         |
| 637_left.jpg   | Lens Dust                             | 2721_left.jpg  | Lens Dust         |
| 637_right.jpg  | Lens Dust                             | 2721_right.jpg | Lens Dust         |
| 659_right.jpg  | Lens Dust                             | 2724_right.jpg | Lens Dust         |
| 664_left.jpg   | Lens Dust                             | 2726_left.jpg  | Lens Dust         |
| 670_right.jpg  | Lens Dust                             | 2727_right.jpg | Lens Dust         |
| 671_right.jpg  | Lens Dust                             | 2729_right.jpg | Lens Dust         |
| 679_left.jpg   | Lens Dust                             | 2734_left.jpg  | Lens Dust         |
| 698_right.jpg  | Lens Dust                             | 2734_right.jpg | Lens Dust         |
| 721_right.jpg  | Lens Dust                             | 2737_left.jpg  | Lens Dust         |
| 793_left.jpg   | Lens Dust                             | 2739_left.jpg  | Lens Dust         |
| 793_right.jpg  | Lens Dust                             | 2741_left.jpg  | Lens Dust         |
| 802_left.jpg   | Lens Dust                             | 2741_right.jpg | Lens Dust         |
| 817_right.jpg  | Lens Dust                             | 2747_right.jpg | Lens Dust         |
| 819_left.jpg   | Lens Dust                             | 2751_left.jpg  | Lens Dust         |
| 819_right.jpg  | Lens Dust                             | 2752_left.jpg  | Lens Dust         |
| 830_left.jpg   | Lens Dust                             | 2752_right.jpg | Lens Dust         |
| 830_right.jpg  | Lens Dust                             | 2756_left.jpg  | Lens Dust         |
| 833_left.jpg   | Lens Dust                             | 2757_right.jpg | Lens Dust         |
| 833_right.jpg  | Lens Dust                             | 2759_left.jpg  | Lens Dust         |
| 842_right.jpg  | Lens Dust                             | 2759_right.jpg | Lens Dust         |
| 843_right.jpg  | Lens Dust                             | 2831_right.jpg | Lens Dust         |
| 844_left.jpg   | Lens Dust                             | 2840_left.jpg  | Lens Dust         |
| 866_right.jpg  | Lens Dust                             | 2840_right.jpg | Lens Dust         |
| 867_right.jpg  | Lens Dust                             | 2851_left.jpg  | Lens Dust         |
| 875_left.jpg   | Lens Dust                             | 2863_left.jpg  | Lens Dust         |
| 882_left.jpg   | Lens Dust                             | 2863_right.jpg | Lens Dust         |
| 895_left.jpg   | Lens Dust                             | 2870_left.jpg  | Lens Dust         |
| 895_right.jpg  | Lens Dust                             | 2870_right.jpg | Lens Dust         |
| 908_left.jpg   | Lens Dust                             | 2875_left.jpg  | Lens Dust         |
| 930_right.jpg  | Lens Dust                             | 2875_right.jpg | Lens Dust         |
| 932_left.jpg   | Lens Dust                             | 2891_left.jpg  | Lens Dust         |
| 932_right.jpg  | Lens Dust                             | 2891_right.jpg | Lens Dust         |
| 955_left.jpg   | Lens Dust                             | 2893_left.jpg  | Lens Dust         |
| 969_right.jpg  | Lens Dust                             | 2893_right.jpg | Lens Dust         |
| 989_left.jpg   | Lens Dust                             | 2894_left.jpg  | Lens Dust         |
| 989_right.jpg  | Lens Dust                             | 2894_right.jpg | Lens Dust         |
| 991_left.jpg   | Lens Dust                             | 2922_left.jpg  | Lens Dust         |
| 993_right.jpg  | Lens Dust                             | 2922_right.jpg | Lens Dust         |
| 1017_left.jpg  | Lens Dust                             | 2928_left.jpg  | Lens Dust         |
| 1017_right.jpg | Lens Dust                             | 2928_right.jpg | Lens Dust         |
| 1033_left.jpg  | Lens Dust                             | 2930_left.jpg  | Lens Dust         |
| 1036_left.jpg  | Lens Dust                             | 2947_left.jpg  | Lens Dust         |
| 1062_left.jpg  | Lens Dust                             | 2947_right.jpg | Lens Dust         |
| 1077_left.jpg  | Lens Dust                             | 2954_right.jpg | Lens Dust         |
| 1095_right.jpg | Lens Dust                             | 2957_right.jpg | Lens Dust         |
| 1096_right.jpg | Lens Dust                             | 2959_left.jpg  | Lens Dust         |
| 1101_left.jpg  | Lens Dust                             | 2959_right.jpg | Lens Dust         |
| 1101_right.jpg | Lens Dust                             | 2968_right.jpg | Lens Dust         |
| 1121_left.jpg  | Lens Dust                             | 3006_left.jpg  | Lens Dust         |
| 1127_left.jpg  | Lens Dust                             | 3006_right.jpg | Lens Dust         |
| 1131_left.jpg  | Lens Dust                             | 3019_right.jpg | Lens Dust         |
| 1131_right.jpg | Lens Dust                             | 3021_right.jpg | Lens Dust         |
| 1134_left.jpg  | Lens Dust                             | 3022_left.jpg  | Lens Dust         |
| 1134_right.jpg | Lens Dust                             | 3022_right.jpg | Lens Dust         |
| 1137_left.jpg  | Lens Dust                             | 3024_left.jpg  | Lens Dust         |
| 1137_right.jpg | Lens Dust                             | 3024_right.jpg | Lens Dust         |
| 1140_left.jpg  | Lens Dust                             | 3031_left.jpg  | Lens Dust         |
| 1140_right.jpg | Lens Dust                             | 3031_right.jpg | Lens Dust         |
| 1228_right.jpg | Optic disk photographically invisible | 3032_left.jpg  | Lens Dust         |
| 1243_left.jpg  | Image Offset                          | 3032_right.jpg | Lens Dust         |
| 1254_left.jpg  | Optic disk photographically invisible | 3037_left.jpg  | Lens Dust         |
| 1310_left.jpg  | Lens Dust                             | 3039_left.jpg  | Lens Dust         |
| 1310_right.jpg | Lens Dust                             | 3039_right.jpg | Lens Dust         |
| 1319_left.jpg  | Optic disk photographically invisible | 3046_left.jpg  | Lens Dust         |
| 1369_right.jpg | Optic disk photographically invisible | 3046_right.jpg | Lens Dust         |
| 1401_left.jpg  | Lens Dust                             | 3049_right.jpg | Lens Dust         |
| 1401_right.jpg | Lens Dust                             | 3053_left.jpg  | Lens Dust         |
| 1409_right.jpg | Lens Dust                             | 3053_right.jpg | Lens Dust         |
| 1455_left.jpg  | Lens Dust                             | 3055_left.jpg  | Lens Dust         |
| 1455_right.jpg | Lens Dust                             | 3055_right.jpg | Lens Dust         |
| 1456_left.jpg  | Lens Dust                             | 3060_left.jpg  | Lens Dust         |
| 1456_right.jpg | Lens Dust                             | 3060_right.jpg | Lens Dust         |
| 1463_left.jpg  | Lens Dust                             | 3118_left.jpg  | Lens Dust         |
| 1463_right.jpg | Lens Dust                             | 3118_right.jpg | Lens Dust         |
| 1475_left.jpg  | Lens Dust                             | 3119_left.jpg  | Lens Dust         |
| 1475_right.jpg | Lens Dust                             | 3119_right.jpg | Lens Dust         |
| 1535_right.jpg | Lens Dust                             | 3133_left.jpg  | Lens Dust         |
| 1540_left.jpg  | Lens Dust                             | 3133_right.jpg | Lens Dust         |
| 1540_right.jpg | Lens Dust                             | 3137_left.jpg  | Lens Dust         |
| 1657_left.jpg  | Lens Dust                             | 3148_left.jpg  | Lens Dust         |
| 1706_left.jpg  | anterior segment image                | 3148_right.jpg | Lens Dust         |
| 1710_right.jpg | anterior segment image                | 3154_left.jpg  | Lens Dust         |
| 1968_left.jpg  | Lens Dust                             | 3154_right.jpg | Lens Dust         |
| 1968_right.jpg | Lens Dust                             | 3158_left.jpg  | Lens Dust         |
| 1970_left.jpg  | Lens Dust                             | 3158_right.jpg | Lens Dust         |
| 1970_right.jpg | Lens Dust                             | 3164_left.jpg  | Lens Dust         |
| 1974_left.jpg  | Lens Dust                             | 3181_left.jpg  | Lens Dust         |
| 1974_right.jpg | Lens Dust                             | 3181_right.jpg | Lens Dust         |
| 1978_left.jpg  | Lens Dust                             | 3184_left.jpg  | Lens Dust         |
| 1978_right.jpg | Lens Dust                             | 3204_right.jpg | Lens Dust         |
| 1984_left.jpg  | Lens Dust                             | 3220_left.jpg  | Lens Dust         |
| 1984_right.jpg | Lens Dust                             | 3220_right.jpg | Lens Dust         |
| 1999_left.jpg  | Lens Dust                             | 3233_left.jpg  | Lens Dust         |
| 1999_right.jpg | Lens Dust                             | 3233_right.jpg | Lens Dust         |
| 2010_right.jpg | Lens Dust                             | 3238_left.jpg  | Lens Dust         |
| 2063_left.jpg  | Lens Dust                             | 3239_left.jpg  | Lens Dust         |
| 2074_left.jpg  | Lens Dust                             | 3239_right.jpg | Lens Dust         |
| 2112_left.jpg  | Lens Dust                             | 3256_left.jpg  | Lens Dust         |
| 2119_right.jpg | Lens Dust                             | 3263_right.jpg | Lens Dust         |
| 2139_left.jpg  | Lens Dust                             | 3265_left.jpg  | Lens Dust         |
| 2159_right.jpg | Lens Dust                             | 3265_right.jpg | Lens Dust         |
| 2174_right.jpg | Wrong Background                      | 3277_left.jpg  | Lens Dust         |
| 2175_left.jpg  | Wrong Background                      | 3277_right.jpg | Lens Dust         |
| 2176_left.jpg  | Wrong Background                      | 3278_left.jpg  | Lens Dust         |
| 2177_left.jpg  | Wrong Background                      | 3278_right.jpg | Lens Dust         |
| 2177_right.jpg | Wrong Background                      | 3279_left.jpg  | Lens Dust         |
| 2178_right.jpg | Wrong Background                      | 3279_right.jpg | Lens Dust         |
| 2179_left.jpg  | Wrong Background                      | 3280_left.jpg  | Lens Dust         |
| 2179_right.jpg | Wrong Background                      | 3280_right.jpg | Lens Dust         |
| 2180_left.jpg  | Wrong Background                      | 3281_left.jpg  | Lens Dust         |
| 2180_right.jpg | Wrong Background                      | 3283_right.jpg | Lens Dust         |
| 2181_left.jpg  | Wrong Background                      | 3292_right.jpg | Lens Dust         |
| 2181_right.jpg | Wrong Background                      | 3300_left.jpg  | Lens Dust         |
| 2182_left.jpg  | Wrong Background                      | 3314_left.jpg  | Lens Dust         |
| 2182_right.jpg | Wrong Background                      | 3314_right.jpg | Lens Dust         |
| 2208_left.jpg  | Lens Dust                             | 3320_left.jpg  | Lens Dust         |
| 2213_left.jpg  | Lens Dust                             | 3322_left.jpg  | Lens Dust         |
| 2214_left.jpg  | Lens Dust                             | 3322_right.jpg | Lens Dust         |
| 2214_right.jpg | Lens Dust                             | 3325_right.jpg | Lens Dust         |
| 2222_left.jpg  | Lens Dust                             | 3346_left.jpg  | Lens Dust         |
| 2229_left.jpg  | Lens Dust                             | 3349_left.jpg  | Lens Dust         |
| 2229_right.jpg | Lens Dust                             | 3349_right.jpg | Lens Dust         |
| 2230_left.jpg  | Lens Dust                             | 3369_left.jpg  | Lens Dust         |
| 2230_right.jpg | Lens Dust                             | 3369_right.jpg | Lens Dust         |
| 2231_left.jpg  | Lens Dust                             | 3383_left.jpg  | Lens Dust         |
| 2231_right.jpg | Lens Dust                             | 3396_left.jpg  | Lens Dust         |
| 2241_left.jpg  | Lens Dust                             | 3396_right.jpg | Lens Dust         |
| 2241_right.jpg | Lens Dust                             | 3398_right.jpg | Lens Dust         |
| 2244_left.jpg  | Lens Dust                             | 3402_left.jpg  | Lens Dust         |
| 2244_right.jpg | Lens Dust                             | 3402_right.jpg | Lens Dust         |
| 2247_right.jpg | Lens Dust                             | 3413_left.jpg  | Lens Dust         |
| 2248_left.jpg  | Lens Dust                             | 3413_right.jpg | Lens Dust         |
| 2248_right.jpg | Lens Dust                             | 3935_left.jpg  | Low Image Quality |
| 2251_left.jpg  | Lens Dust                             | 3947_right.jpg | Low Image Quality |
| 2251_right.jpg | Lens Dust                             | 4007_left.jpg  | Low Image Quality |
| 2344_left.jpg  | Lens Dust                             | 4066_right.jpg | Low Image Quality |
| 2344_right.jpg | Lens Dust                             | 4124_right.jpg | Low Image Quality |
| 2350_left.jpg  | Lens Dust                             | 4149_left.jpg  | Low Image Quality |
| 2350_right.jpg | Lens Dust                             | 4149_right.jpg | Low Image Quality |
| 2357_left.jpg  | Lens Dust                             | 4169_left.jpg  | Low Image Quality |
| 2357_right.jpg | Lens Dust                             | 4180_right.jpg | Low Image Quality |
| 2358_left.jpg  | Lens Dust                             | 4198_right.jpg | Low Image Quality |
| 2358_right.jpg | Lens Dust                             | 4262_right.jpg | Low Image Quality |
| 2370_right.jpg | Lens Dust                             | 4290_left.jpg  | Low Image Quality |
| 2377_right.jpg | Lens Dust                             | 4319_right.jpg | Low Image Quality |
| 2400_left.jpg  | Lens Dust                             | 4394_right.jpg | Low Image Quality |
| 2428_left.jpg  | Lens Dust                             | 4427_right.jpg | Low Image Quality |
| 2428_right.jpg | Lens Dust                             | 4442_left.jpg  | Low Image Quality |
| 2448_right.jpg | Lens Dust                             | 4448_left.jpg  | Low Image Quality |
| 4522_left.jpg  | Low Image Quality                     | 4580_left.jpg  | no fundus image   |
| 4601_right.jpg | Low Image Quality                     |                |                   |

